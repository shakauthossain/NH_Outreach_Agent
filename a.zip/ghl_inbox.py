import os
import httpx
from fastapi import APIRouter, HTTPException

GHL_API_BASE = "https://services.leadconnectorhq.com"
GoHighLevel_key = os.getenv("GOHIGHLEVEL_KEY")
Location_ID = os.getenv("GOHIGHLEVEL_LOCATION_ID")

headers = {
        "Authorization": f"Bearer {GoHighLevel_key}",
        "Version": "2021-07-28",
        "Content-Type": "application/json"
    }

router = APIRouter(prefix="/emails", tags=["Inbox"])

@router.get("/inbox")
async def get_inbox_conversations():
    url = f"{GHL_API_BASE}/locations/{Location_ID}/conversations"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            emails = [c for c in data.get("conversations", []) if c.get("type") == "Email"]
            return {"inbox": emails}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)

@router.get("/{conversation_id}")
async def get_conversation_detail(conversation_id: str):
    url = f"{GHL_API_BASE}/locations/{Location_ID}/conversations/{conversation_id}/messages"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return {"messages": resp.json().get("messages", [])}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
